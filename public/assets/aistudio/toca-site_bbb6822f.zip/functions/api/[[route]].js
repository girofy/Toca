const J=(o,s=200,h={})=>new Response(JSON.stringify(o),{status:s,headers:{'content-type':'application/json','cache-control':'no-store',...h}});
const enc=new TextEncoder(),b64=b=>btoa(String.fromCharCode(...new Uint8Array(b))),ub64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
const kget=async(db,k)=>{const r=await db.prepare('SELECT v FROM kv WHERE k=?').bind(k).first();return r?r.v:null};
const kset=(db,k,v)=>db.prepare('INSERT INTO kv(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v').bind(k,v).run();
async function hash(pw,salt){const k=await crypto.subtle.importKey('raw',enc.encode(pw),'PBKDF2',false,['deriveBits']);return b64(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt,iterations:100000},k,256))}
async function sign(sec,msg){const k=await crypto.subtle.importKey('raw',enc.encode(sec),{name:'HMAC',hash:'SHA-256'},false,['sign']);return b64(await crypto.subtle.sign('HMAC',k,enc.encode(msg)))}
async function sess(db){const sec=await kget(db,'secret'),exp=Date.now()+6048e5;return J({ok:1},200,{'set-cookie':'sid='+encodeURIComponent(exp+'.'+await sign(sec,String(exp)))+'; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=604800'})}
async function authed(req,db){const m=(req.headers.get('cookie')||'').match(/sid=([^;]+)/);if(!m)return false;const[exp,sig]=decodeURIComponent(m[1]).split('.');if(!exp||+exp<Date.now())return false;const sec=await kget(db,'secret');return !!sec&&sig===await sign(sec,exp)}
const KEYS=['h1a','h1b','sub','cta','l40','l100','phone','waMsg','scText','ends'],D=864e5,TZ=108e5;
export async function onRequest({request,env}){
const db=env.DB,p=new URL(request.url).pathname.replace(/^\/api\//,'').replace(/\/$/,''),m=request.method;
if(!db)return J({error:'Banco D1 não conectado (binding DB).'},500);
if(p=='config'&&m=='GET'){const c=await kget(db,'cfg');return J(c?JSON.parse(c):{})}
if(p=='track'&&m=='POST'){const b=await request.json().catch(()=>({})),cf=request.cf||{},ua=request.headers.get('user-agent')||'';
await db.prepare('INSERT INTO ev(ts,t,l,city,dev) VALUES(?,?,?,?,?)').bind(Date.now(),b.t=='click'?'click':'view',String(b.l||'').slice(0,40),String(cf.city||'').slice(0,40),/mobile/i.test(ua)?'m':'d').run();return J({ok:1})}
if(p=='status')return J({setup:!(await kget(db,'pw')),code:!!env.SETUP_CODE});
if(p=='setup'&&m=='POST'){if(await kget(db,'pw'))return J({error:'Já configurado.'},403);const b=await request.json().catch(()=>({}));
if(env.SETUP_CODE&&b.code!==env.SETUP_CODE)return J({error:'Código de ativação incorreto.'},403);
if(!b.password||b.password.length<10)return J({error:'A senha precisa ter pelo menos 10 caracteres.'},400);
const salt=crypto.getRandomValues(new Uint8Array(16));await kset(db,'pw',b64(salt)+'.'+await hash(b.password,salt));await kset(db,'secret',b64(crypto.getRandomValues(new Uint8Array(32))));return sess(db)}
if(p=='login'&&m=='POST'){const f=JSON.parse(await kget(db,'fails')||'{"n":0,"t":0}');if(f.n>=5&&Date.now()-f.t<6e4)return J({error:'Muitas tentativas. Espere 1 minuto.'},429);
const b=await request.json().catch(()=>({})),sv=await kget(db,'pw');if(!sv||!b.password)return J({error:'Senha incorreta.'},401);const[s,h]=sv.split('.');
if(await hash(b.password,ub64(s))!==h){await kset(db,'fails',JSON.stringify({n:f.n+1,t:Date.now()}));return J({error:'Senha incorreta.'},401)}
await kset(db,'fails','{"n":0,"t":0}');return sess(db)}
if(!await authed(request,db))return J({error:'Não autorizado.'},401);
if(p=='logout')return J({ok:1},200,{'set-cookie':'sid=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0'});
if(p=='stats'){const now=Date.now(),t0=Math.floor((now-TZ)/D)*D+TZ,d13=t0-13*D;
const tot=await db.prepare("SELECT COALESCE(SUM(ts>=?),0) a,COALESCE(SUM(ts>=?),0) b,COUNT(*) c FROM ev WHERE t='view' AND ts>=?").bind(t0,t0-6*D,now-30*D).first();
const dr=await db.prepare("SELECT CAST((ts-?)/86400000 AS INTEGER) i,COUNT(*) n FROM ev WHERE t='view' AND ts>=? GROUP BY i").bind(d13,d13).all();
const mp={};for(const r of dr.results)mp[r.i]=r.n;const days=[];for(let i=0;i<14;i++)days.push({d:new Date(d13+i*D-TZ).toISOString().slice(5,10).split('-').reverse().join('/'),n:mp[i]||0});
const q=async s=>(await db.prepare(s).bind(now-30*D).all()).results;
return J({today:tot.a,week:tot.b,month:tot.c,days,
clicks:await q("SELECT l,COUNT(*) n FROM ev WHERE t='click' AND ts>=? GROUP BY l ORDER BY n DESC"),
cities:await q("SELECT COALESCE(NULLIF(city,''),'Não identificada') l,COUNT(*) n FROM ev WHERE t='view' AND ts>=? GROUP BY l ORDER BY n DESC LIMIT 8"),
devices:await q("SELECT dev l,COUNT(*) n FROM ev WHERE t='view' AND ts>=? GROUP BY dev")})}
if(p=='config'&&m=='PUT'){const b=await request.json().catch(()=>({})),c={};for(const k of KEYS)if(typeof b[k]=='string'&&b[k].trim())c[k]=b[k].trim().slice(0,400);
for(const k of['l40','l100'])if(c[k]&&!/^https:\/\//.test(c[k]))return J({error:'Links precisam começar com https://'},400);
c.scOn=!!b.scOn;c.scLeft=Math.max(0,parseInt(b.scLeft)||0);await kset(db,'cfg',JSON.stringify(c));return J({ok:1})}
return J({error:'Não encontrado.'},404)}
